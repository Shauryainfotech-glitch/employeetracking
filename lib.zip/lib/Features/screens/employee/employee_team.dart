import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:intl/intl.dart';

class TeamPage extends StatefulWidget {
  @override
  _TeamPageState createState() => _TeamPageState();
}

class _TeamPageState extends State<TeamPage> {
  int _currentFilterIndex = 0;
  final List<String> _filters = ['All', 'Present', 'Remote', 'Absent'];
  final List<TeamMember> _teamMembers = [
    TeamMember(
      name: 'Alex Johnson',
      role: 'Senior Developer',
      status: 'Present',
      lastActive: DateTime.now().subtract(Duration(minutes: 15)),
      avatarColor: Colors.blue,
      tasksCompleted: 12,
      productivity: 85,
    ),
    TeamMember(
      name: 'Maria Garcia',
      role: 'UX Designer',
      status: 'Remote',
      lastActive: DateTime.now().subtract(Duration(hours: 2)),
      avatarColor: Colors.purple,
      tasksCompleted: 8,
      productivity: 72,
    ),
    TeamMember(
      name: 'James Wilson',
      role: 'Project Manager',
      status: 'Present',
      lastActive: DateTime.now().subtract(Duration(minutes: 45)),
      avatarColor: Colors.orange,
      tasksCompleted: 5,
      productivity: 90,
    ),
    TeamMember(
      name: 'Sarah Lee',
      role: 'QA Engineer',
      status: 'Absent',
      lastActive: DateTime.now().subtract(Duration(days: 1)),
      avatarColor: Colors.green,
      tasksCompleted: 15,
      productivity: 68,
    ),
    TeamMember(
      name: 'David Kim',
      role: 'DevOps Engineer',
      status: 'Remote',
      lastActive: DateTime.now().subtract(Duration(hours: 3)),
      avatarColor: Colors.red,
      tasksCompleted: 10,
      productivity: 78,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return [
            SliverAppBar(
              expandedHeight: 120,
              floating: true,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                title: Text('Team Overview', style: TextStyle(color: Colors.black87)),
                background: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Colors.blue[50]!, Colors.white],
                    ),
                  ),
                ),
              ),
            ),
            SliverPersistentHeader(
              pinned: true,
              delegate: _FilterHeaderDelegate(
                child: _buildFilterChips(),
              ),
            ),
          ];
        },
        body: Column(
          children: [
            Expanded(
              child: _buildTeamList(),
            ),
            _buildTeamCalendar(),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChips() {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.symmetric(vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: _filters.map((filter) {
            final index = _filters.indexOf(filter);
            return Padding(
              padding: EdgeInsets.symmetric(horizontal: 4),
              child: FilterChip(
                label: Text(filter),
                selected: _currentFilterIndex == index,
                selectedColor: Colors.blue[100],
                checkmarkColor: Colors.blue,
                labelStyle: TextStyle(
                  color: _currentFilterIndex == index ? Colors.blue : Colors.black87,
                  fontWeight: FontWeight.w500,
                ),
                onSelected: (selected) {
                  setState(() {
                    _currentFilterIndex = index;
                  });
                },
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildTeamList() {
    List<TeamMember> filteredMembers = _teamMembers;
    if (_currentFilterIndex > 0) {
      filteredMembers = _teamMembers
          .where((member) => member.status == _filters[_currentFilterIndex])
          .toList();
    }

    return ListView.separated(
      padding: EdgeInsets.all(16),
      itemCount: filteredMembers.length,
      separatorBuilder: (context, index) => SizedBox(height: 12),
      itemBuilder: (context, index) {
        final member = filteredMembers[index];
        return _buildTeamMemberCard(member);
      },
    );
  }

  Widget _buildTeamMemberCard(TeamMember member) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          // Navigate to member details
        },
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              _buildMemberAvatar(member),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      member.name,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      member.role,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 8),
                    _buildStatusRow(member),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _buildLastActiveTime(member),
                  SizedBox(height: 8),
                  _buildProductivityIndicator(member),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMemberAvatar(TeamMember member) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                member.avatarColor.withOpacity(0.3),
                member.avatarColor.withOpacity(0.1),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              member.name.substring(0, 1),
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: member.avatarColor,
              ),
            ),
          ),
        ),
        Positioned(
          right: 0,
          bottom: 0,
          child: Container(
            width: 14,
            height: 14,
            decoration: BoxDecoration(
              color: _getStatusColor(member.status),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatusRow(TeamMember member) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: _getStatusColor(member.status),
            shape: BoxShape.circle,
          ),
        ),
        SizedBox(width: 8),
        Text(
          member.status,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
        Spacer(),
        _buildTaskBadge(member),
      ],
    );
  }

  Widget _buildTaskBadge(TeamMember member) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        '${member.tasksCompleted} tasks',
        style: TextStyle(
          fontSize: 12,
          color: Colors.blue[800],
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildLastActiveTime(TeamMember member) {
    final difference = DateTime.now().difference(member.lastActive);
    String timeText;

    if (difference.inDays > 0) {
      timeText = '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      timeText = '${difference.inHours}h ago';
    } else {
      timeText = '${difference.inMinutes}m ago';
    }

    return Text(
      timeText,
      style: TextStyle(
        fontSize: 12,
        color: Colors.grey[500],
      ),
    );
  }

  Widget _buildProductivityIndicator(TeamMember member) {
    return Container(
      width: 80,
      height: 6,
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(3),
      ),
      child: Row(
        children: [
          Expanded(
            flex: member.productivity,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.green[400]!,
                    Colors.lightGreen[300]!,
                  ],
                ),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          ),
          Expanded(
            flex: 100 - member.productivity,
            child: SizedBox(),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamCalendar() {
    return Container(
      height: 400,
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: SfCalendar(
          view: CalendarView.week,
          dataSource: MeetingDataSource(_getTeamMeetings()),
          headerStyle: CalendarHeaderStyle(
            textAlign: TextAlign.center,
            backgroundColor: Colors.transparent,
            textStyle: TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.w500,
            ),
          ),
          monthViewSettings: MonthViewSettings(
            showAgenda: true,
          ),
          appointmentTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 12,
          ),
          todayHighlightColor: Colors.blue,
        ),
      ),
    );
  }

  List<Meeting> _getTeamMeetings() {
    return [
      Meeting(
        'Team Sync',
        DateTime.now().add(Duration(hours: 1)),
        DateTime.now().add(Duration(hours: 2)),
        [Colors.blue[400]!, Colors.blue[600]!],
        false,
      ),
      Meeting(
        'Sprint Planning',
        DateTime.now().add(Duration(days: 1, hours: 10)),
        DateTime.now().add(Duration(days: 1, hours: 12)),
        [Colors.green[400]!, Colors.teal[300]!],
        false,
      ),
      Meeting(
        '1:1 with Manager',
        DateTime.now().add(Duration(days: 2, hours: 14)),
        DateTime.now().add(Duration(days: 2, hours: 15)),
        [Colors.purple[400]!, Colors.deepPurple[300]!],
        true,
      ),
    ];
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Present':
        return Colors.green;
      case 'Remote':
        return Colors.blue;
      case 'Absent':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}

class _FilterHeaderDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;

  _FilterHeaderDelegate({required this.child});

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return child;
  }

  @override
  double get maxExtent => 56;

  @override
  double get minExtent => 56;

  @override
  bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) {
    return true;
  }
}

class TeamMember {
  final String name;
  final String role;
  final String status;
  final DateTime lastActive;
  final Color avatarColor;
  final int tasksCompleted;
  final int productivity;

  TeamMember({
    required this.name,
    required this.role,
    required this.status,
    required this.lastActive,
    required this.avatarColor,
    required this.tasksCompleted,
    required this.productivity,
  });
}

class MeetingDataSource extends CalendarDataSource {
  MeetingDataSource(List<Meeting> source) {
    appointments = source;
  }

  @override
  DateTime getStartTime(int index) {
    return appointments![index].from;
  }

  @override
  DateTime getEndTime(int index) {
    return appointments![index].to;
  }

  @override
  String getSubject(int index) {
    return appointments![index].eventName;
  }

  @override
  Color getColor(int index) {
    return appointments![index].background.last;
  }

  @override
  bool isAllDay(int index) {
    return appointments![index].isAllDay;
  }
}

class Meeting {
  Meeting(this.eventName, this.from, this.to, this.background, this.isAllDay);

  String eventName;
  DateTime from;
  DateTime to;
  List<Color> background;
  bool isAllDay;
}