import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class TrackingPage extends StatefulWidget {
  @override
  _TrackingPageState createState() => _TrackingPageState();
}

class _TrackingPageState extends State<TrackingPage> with SingleTickerProviderStateMixin {
  late MapController _mapController;
  Position? _currentPosition;
  bool _isTracking = false;
  late AnimationController _animationController;
  List<LatLng> _routePoints = [];
  double _batteryLevel = 0.85;
  double _speed = 0.0;
  double _zoom = 15.0;

  @override
  void initState() {
    super.initState();
    _mapController = MapController();
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 500),
    );
    _getCurrentLocation();
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }

    Position position = await Geolocator.getCurrentPosition();
    setState(() {
      _currentPosition = position;
      _routePoints.add(LatLng(position.latitude, position.longitude));
      _speed = position.speed;
    });

    if (_isTracking) {
      _mapController.move(
        LatLng(position.latitude, position.longitude),
        _zoom,
      );
    }
  }

  void _toggleTracking() {
    setState(() {
      _isTracking = !_isTracking;
      if (_isTracking) {
        _animationController.repeat(reverse: true);
        _startLocationUpdates();
      } else {
        _animationController.stop();
      }
    });
  }

  void _startLocationUpdates() {
    Geolocator.getPositionStream().listen((Position position) {
      if (!_isTracking) return;

      setState(() {
        _currentPosition = position;
        _routePoints.add(LatLng(position.latitude, position.longitude));
        _speed = position.speed;
      });

      _mapController.move(
        LatLng(position.latitude, position.longitude),
        _zoom,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Map View
          _buildMap(),

          // Header
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            left: 16,
            right: 16,
            child: _buildHeader(),
          ),

          // Tracking Controls
          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 100,
            right: 16,
            child: _buildTrackingButton(),
          ),

          // Stats Panel
          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 16,
            left: 16,
            right: 16,
            child: _buildStatsPanel(),
          ),
        ],
      ),
    );
  }

  Widget _buildMap() {
    if (_currentPosition == null) {
      return Center(child: CircularProgressIndicator());
    }

    return FlutterMap(
      mapController: _mapController,
      options: MapOptions(
        initialCenter: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
        initialZoom: _zoom,
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
          subdomains: ['a', 'b', 'c'],
        ),
        PolylineLayer(
          polylines: [
            Polyline(
              points: _routePoints,
              strokeWidth: 4.0,
              color: Colors.blue,
            ),
          ],
        ),
        MarkerLayer(
          markers: [
            Marker(
              width: 40,
              height: 40,
              point: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
              child: Transform.translate(
                offset: Offset(0, -20),
                child: AnimatedBuilder(
                  animation: _animationController,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _isTracking ? 1.0 + _animationController.value * 0.2 : 1.0,
                      child: Icon(
                        Icons.location_pin,
                        color: Colors.red,
                        size: 40,
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(Icons.location_on, color: Colors.blue),
            SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Live Tracking',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _currentPosition != null
                        ? '${_currentPosition!.latitude.toStringAsFixed(4)}, ${_currentPosition!.longitude.toStringAsFixed(4)}'
                        : 'Acquiring location...',
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: Icon(Icons.settings),
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTrackingButton() {
    return FloatingActionButton(
      backgroundColor: _isTracking ? Colors.red : Colors.green,
      child: Icon(
        _isTracking ? Icons.stop : Icons.play_arrow,
        color: Colors.white,
      ),
      onPressed: _toggleTracking,
    );
  }

  Widget _buildStatsPanel() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildStatItem('Distance', '${_routePoints.length * 0.02} km', Icons.directions_walk),
                _buildStatItem('Speed', '${_speed.toStringAsFixed(1)} km/h', Icons.speed),
                _buildStatItem('Battery', '${(_batteryLevel * 100).toStringAsFixed(0)}%', Icons.battery_std),
              ],
            ),
            SizedBox(height: 12),
            _buildBatteryGauge(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String title, String value, IconData icon) {
    return Column(
      children: [
        Row(
          children: [
            Icon(icon, size: 16, color: Colors.blue),
            SizedBox(width: 4),
            Text(title, style: TextStyle(fontSize: 12)),
          ],
        ),
        SizedBox(height: 4),
        Text(value, style: TextStyle(fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildBatteryGauge() {
    return SizedBox(
      height: 80,
      child: SfLinearGauge(
        minimum: 0,
        maximum: 100,
        interval: 25,
        orientation: LinearGaugeOrientation.horizontal,
        ranges: [
          LinearGaugeRange(
            startValue: 0,
            endValue: 20,
            color: Colors.red,
          ),
          LinearGaugeRange(
            startValue: 20,
            endValue: 50,
            color: Colors.orange,
          ),
          LinearGaugeRange(
            startValue: 50,
            endValue: 100,
            color: Colors.green,
          ),
        ],
        markerPointers: [
          LinearShapePointer(
            value: _batteryLevel * 100,
            height: 15,
            width: 15,
            shapeType: LinearShapePointerType.diamond,
          )
        ],
        barPointers: [
          LinearBarPointer(
            value: _batteryLevel * 100,
            thickness: 10,
            color: Colors.transparent,
            edgeStyle: LinearEdgeStyle.bothFlat,
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}