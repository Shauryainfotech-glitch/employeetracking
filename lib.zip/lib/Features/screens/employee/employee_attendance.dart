import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

class AttendancePage extends StatefulWidget {
  @override
  _AttendancePageState createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  DateTime _selectedDate = DateTime.now();
  bool _isPresent = false;
  bool _isOnLeave = false;
  TimeOfDay _checkInTime = TimeOfDay.now();
  TimeOfDay _checkOutTime = TimeOfDay(hour: 17, minute: 30);

  List<AttendanceRecord> _attendanceRecords = [
    AttendanceRecord(
      date: DateTime.now().subtract(Duration(days: 2)),
      checkIn: TimeOfDay(hour: 9, minute: 15),
      checkOut: TimeOfDay(hour: 17, minute: 30),
      status: 'Present',
    ),
    AttendanceRecord(
      date: DateTime.now().subtract(Duration(days: 1)),
      checkIn: TimeOfDay(hour: 9, minute: 30),
      checkOut: TimeOfDay(hour: 17, minute: 45),
      status: 'Present',
    ),
    // Add more sample records as needed
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Tracking'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.calendar_today),
            onPressed: () => _selectDate(context),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            _buildDateHeader(),
            SizedBox(height: 20),
            _buildAttendanceStatusCard(),
            SizedBox(height: 20),
            _buildTimeTracker(),
            SizedBox(height: 20),
            _buildCalendarView(),
            SizedBox(height: 20),
            _buildAttendanceHistory(),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () => _markAttendance(context),
      ),
    );
  }

  Widget _buildDateHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          DateFormat('EEEE, MMMM d').format(_selectedDate),
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Chip(
          label: Text(
            DateFormat('yyyy').format(_selectedDate),
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.blue,
        ),
      ],
    );
  }

  Widget _buildAttendanceStatusCard() {
    String status = _isOnLeave ? 'On Leave' : (_isPresent ? 'Present' : 'Absent');
    Color statusColor = _isOnLeave ? Colors.orange : (_isPresent ? Colors.green : Colors.red);

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Today\'s Status',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    status,
                    style: TextStyle(color: statusColor, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            LinearProgressIndicator(
              value: _calculateMonthlyAttendance(),
              backgroundColor: Colors.grey[200],
              valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
            ),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Monthly Attendance',
                  style: TextStyle(color: Colors.grey),
                ),
                Text(
                  '${(_calculateMonthlyAttendance() * 100).toStringAsFixed(0)}%',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeTracker() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildTimeCard('Check In', _checkInTime),
                Container(
                  width: 1,
                  height: 50,
                  color: Colors.grey[300],
                ),
                _buildTimeCard('Check Out', _checkOutTime),
              ],
            ),
            SizedBox(height: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              child: Text(
                _isPresent ? 'Check Out' : 'Check In',
                style: TextStyle(fontSize: 16),
              ),
              onPressed: () => _recordAttendance(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeCard(String label, TimeOfDay time) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(color: Colors.grey),
        ),
        SizedBox(height: 4),
        Text(
          time.format(context),
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget _buildCalendarView() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        height: 350,
        padding: EdgeInsets.all(8),
        child: SfCalendar(
          view: CalendarView.month,
          dataSource: AttendanceDataSource(_getAppointments()),
          monthViewSettings: MonthViewSettings(
            showAgenda: true,
            appointmentDisplayMode: MonthAppointmentDisplayMode.appointment,
          ),
          onTap: (CalendarTapDetails details) {
            if (details.targetElement == CalendarElement.calendarCell) {
              setState(() {
                _selectedDate = details.date!;
              });
            }
          },
        ),
      ),
    );
  }

  Widget _buildAttendanceHistory() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recent Attendance',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 8),
        ..._attendanceRecords.map((record) => _buildAttendanceRecordItem(record)).toList(),
      ],
    );
  }

  Widget _buildAttendanceRecordItem(AttendanceRecord record) {
    Color statusColor = record.status == 'Present'
        ? Colors.green
        : record.status == 'On Leave'
        ? Colors.orange
        : Colors.red;

    return Card(
      margin: EdgeInsets.only(bottom: 8),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
      child: ListTile(
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: statusColor.withOpacity(0.2),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              DateFormat('d').format(record.date),
              style: TextStyle(
                color: statusColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        title: Text(DateFormat('EEEE, MMMM d').format(record.date)),
        subtitle: Text(
          '${record.checkIn.format(context)} - ${record.checkOut.format(context)}',
        ),
        trailing: Chip(
          label: Text(
            record.status,
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: statusColor,
        ),
      ),
    );
  }

  double _calculateMonthlyAttendance() {
    // In a real app, you would calculate this based on actual attendance data
    return 0.85; // 85% attendance for demo purposes
  }

  List<Appointment> _getAppointments() {
    // Convert attendance records to calendar appointments
    return _attendanceRecords.map((record) {
      Color color = record.status == 'Present'
          ? Colors.green
          : record.status == 'On Leave'
          ? Colors.orange
          : Colors.red;

      DateTime date = record.date;
      DateTime startTime = DateTime(
          date.year, date.month, date.day, record.checkIn.hour, record.checkIn.minute);
      DateTime endTime = DateTime(
          date.year, date.month, date.day, record.checkOut.hour, record.checkOut.minute);

      return Appointment(
        startTime: startTime,
        endTime: endTime,
        subject: record.status,
        color: color,
      );
    }).toList();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _recordAttendance() {
    setState(() {
      if (_isPresent) {
        // Check out
        _checkOutTime = TimeOfDay.now();
      } else {
        // Check in
        _checkInTime = TimeOfDay.now();
        _isPresent = true;
      }
    });

    // In a real app, you would save this to your database
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _isPresent ? 'Checked in successfully!' : 'Checked out successfully!',
        ),
      ),
    );
  }

  Future<void> _markAttendance(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Mark Attendance',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),
                  RadioListTile(
                    title: Text('Present'),
                    value: true,
                    groupValue: _isOnLeave ? false : _isPresent,
                    onChanged: (value) {
                      setModalState(() {
                        _isPresent = value as bool;
                        _isOnLeave = false;
                      });
                    },
                  ),
                  RadioListTile(
                    title: Text('On Leave'),
                    value: true,
                    groupValue: _isOnLeave,
                    onChanged: (value) {
                      setModalState(() {
                        _isOnLeave = value as bool;
                        _isPresent = false;
                      });
                    },
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      TextButton(
                        child: Text('Cancel'),
                        onPressed: () => Navigator.pop(context),
                      ),
                      ElevatedButton(
                        child: Text('Save'),
                        onPressed: () {
                          setState(() {});
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Attendance marked successfully!'),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class AttendanceRecord {
  final DateTime date;
  final TimeOfDay checkIn;
  final TimeOfDay checkOut;
  final String status;

  AttendanceRecord({
    required this.date,
    required this.checkIn,
    required this.checkOut,
    required this.status,
  });
}

class AttendanceDataSource extends CalendarDataSource {
  AttendanceDataSource(List<Appointment> source) {
    appointments = source;
  }
}