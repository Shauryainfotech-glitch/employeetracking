import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class HRAnalyticsScreen extends StatefulWidget {
  @override
  _HRAnalyticsScreenState createState() => _HRAnalyticsScreenState();
}

class _HRAnalyticsScreenState extends State<HRAnalyticsScreen> with SingleTickerProviderStateMixin {
  final List<Employee> _employees = [
    Employee(
      id: '1',
      name: 'John Doe',
      position: 'Android Developer',
      productivity: 85,
      attendance: 92,
      lastActive: DateTime.now().subtract(Duration(minutes: 15)),
      isActive: true,
      department: 'Development',
      skills: ['Flutter', 'Kotlin', 'Android SDK'],
      joinDate: DateTime(2020, 5, 15),
      imageUrl: 'https://randomuser.me/api/portraits/men/1.jpg',
    ),
    Employee(
      id: '2',
      name: 'Jane Smith',
      position: 'UI/UX Designer',
      productivity: 78,
      attendance: 88,
      lastActive: DateTime.now().subtract(Duration(hours: 2)),
      isActive: false,
      department: 'Design',
      skills: ['Figma', 'Adobe XD', 'User Research'],
      joinDate: DateTime(2021, 2, 10),
      imageUrl: 'https://randomuser.me/api/portraits/women/1.jpg',
    ),
    Employee(
      id: '3',
      name: 'Mike Johnson',
      position: 'Data Scientist',
      productivity: 92,
      attendance: 95,
      lastActive: DateTime.now().subtract(Duration(minutes: 45)),
      isActive: true,
      department: 'Data',
      skills: ['Python', 'Machine Learning', 'SQL'],
      joinDate: DateTime(2019, 8, 22),
      imageUrl: 'https://randomuser.me/api/portraits/men/2.jpg',
    ),
    Employee(
      id: '4',
      name: 'Sarah Williams',
      position: 'QA Engineer',
      productivity: 82,
      attendance: 90,
      lastActive: DateTime.now().subtract(Duration(hours: 1)),
      isActive: true,
      department: 'Development',
      skills: ['Automation', 'Manual Testing', 'Selenium'],
      joinDate: DateTime(2022, 1, 5),
      imageUrl: 'https://randomuser.me/api/portraits/women/2.jpg',
    ),
    Employee(
      id: '5',
      name: 'David Brown',
      position: 'Project Manager',
      productivity: 88,
      attendance: 94,
      lastActive: DateTime.now().subtract(Duration(minutes: 30)),
      isActive: true,
      department: 'Management',
      skills: ['Agile', 'Scrum', 'JIRA'],
      joinDate: DateTime(2018, 11, 30),
      imageUrl: 'https://randomuser.me/api/portraits/men/3.jpg',
    ),
  ];

  String _selectedFilter = 'All';
  final List<String> _filters = ['All', 'Development', 'Design', 'Data', 'Management'];
  String _selectedTimeRange = 'Monthly';
  final List<String> _timeRanges = ['Weekly', 'Monthly', 'Quarterly', 'Yearly'];
  int _currentPageIndex = 0;
  late TabController _tabController;
  bool _showAdvancedFilters = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentPageIndex = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filteredEmployees = _selectedFilter == 'All'
        ? _employees
        : _employees.where((e) => e.department == _selectedFilter).toList();

    // Calculate overall statistics
    final totalEmployees = _employees.length;
    final activeEmployees = _employees.where((e) => e.isActive).length;
    final avgProductivity = (_employees.fold(0, (sum, e) => sum + e.productivity) / _employees.length).round();
    final avgAttendance = (_employees.fold(0, (sum, e) => sum + e.attendance) / _employees.length).round();

    return Scaffold(
      backgroundColor: Color(0xFFF8FAFD),
      appBar: AppBar(
        title: Text('Employee Analytics', style: TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 20,
        )),
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        actions: [
          IconButton(
            icon: Icon(Icons.search, color: Color(0xFF5F6C7D)),
            onPressed: () {
              showSearch(
                context: context,
                delegate: EmployeeSearchDelegate(_employees),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.filter_alt, color: Color(0xFF5F6C7D)),
            onPressed: () => setState(() => _showAdvancedFilters = !_showAdvancedFilters),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(80),
          child: Column(
            children: [
              _buildFilterSection(),
              if (_showAdvancedFilters) _buildAdvancedFilters(),
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: _buildStatsOverview(totalEmployees, activeEmployees, avgProductivity, avgAttendance),
            ),
            SizedBox(height: 16),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: _buildTimeRangeSelector(),
            ),
            SizedBox(height: 16),
            Container(
              height: 320,
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildProductivityChart(filteredEmployees),
                  _buildAttendanceChart(filteredEmployees),
                  _buildDepartmentComparisonChart(filteredEmployees),
                ],
              ),
            ),
            _buildTabIndicator(),
            SizedBox(height: 16),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: _buildPerformanceTable(filteredEmployees),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFF3366FF),
        child: Icon(Icons.add, color: Colors.white),
        onPressed: () => _showAddEmployeeDialog(),
        tooltip: 'Add New Employee',
      ),
    );
  }

  Widget _buildStatsOverview(int total, int active, int avgProd, int avgAtt) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 2,
          )
        ],
      ),
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatItem('Total Employees', total.toString(), Icons.people_outline, Color(0xFF3366FF)),
              _buildStatItem('Active Now', active.toString(), Icons.person_outline, Color(0xFF00B8D9)),
            ],
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatItem('Avg Productivity', '$avgProd%', Icons.trending_up_outlined, Color(0xFF00A76F)),
              _buildStatItem('Avg Attendance', '$avgAtt%', Icons.calendar_today_outlined, Color(0xFFFF5630)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 20, color: color),
            ),
            SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1A1A1A),
                  ),
                ),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF5F6C7D),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterSection() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Department',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Color(0xFF5F6C7D),
            ),
          ),
          SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: _filters.map((filter) {
                return Padding(
                  padding: EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(filter),
                    selected: _selectedFilter == filter,
                    selectedColor: Color(0xFF3366FF),
                    labelStyle: TextStyle(
                      color: _selectedFilter == filter ? Colors.white : Color(0xFF1A1A1A),
                      fontSize: 12,
                    ),
                    onSelected: (selected) {
                      setState(() {
                        _selectedFilter = filter;
                      });
                    },
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    showCheckmark: false,
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAdvancedFilters() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(color: Colors.grey[200]!),
          bottom: BorderSide(color: Colors.grey[200]!),
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Advanced Filters', style: TextStyle(fontWeight: FontWeight.bold)),
              IconButton(
                icon: Icon(Icons.close, size: 20),
                onPressed: () => setState(() => _showAdvancedFilters = false),
              ),
            ],
          ),
          SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _buildAdvancedFilterChip('Active Only', Icons.person),
              _buildAdvancedFilterChip('High Performers', Icons.star),
              _buildAdvancedFilterChip('New Hires', Icons.new_releases),
              _buildAdvancedFilterChip('Needs Review', Icons.warning),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAdvancedFilterChip(String label, IconData icon) {
    return ChoiceChip(
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          SizedBox(width: 4),
          Text(label),
        ],
      ),
      selected: false,
      onSelected: (selected) {},
      selectedColor: Color(0xFF3366FF).withOpacity(0.2),
      backgroundColor: Colors.grey[100],
      labelStyle: TextStyle(fontSize: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }

  Widget _buildTimeRangeSelector() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 2,
          )
        ],
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Time Range',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Color(0xFF5F6C7D),
            ),
          ),
          SizedBox(height: 8),
          ToggleButtons(
            isSelected: _timeRanges.map((range) => _selectedTimeRange == range).toList(),
            onPressed: (index) {
              setState(() {
                _selectedTimeRange = _timeRanges[index];
              });
            },
            children: _timeRanges.map((range) => Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Text(range),
            )).toList(),
            borderRadius: BorderRadius.circular(8),
            constraints: BoxConstraints(minHeight: 36),
            selectedColor: Color(0xFF3366FF),
            fillColor: Color(0xFF3366FF).withOpacity(0.1),
            color: Color(0xFF1A1A1A),
            selectedBorderColor: Color(0xFF3366FF),
            borderColor: Colors.grey[300],
          ),
        ],
      ),
    );
  }

  Widget _buildProductivityChart(List<Employee> employees) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 2,
          )
        ],
      ),
      margin: EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Productivity',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1A1A1A),
                ),
              ),
              IconButton(
                icon: Icon(Icons.info_outline, size: 18, color: Color(0xFF5F6C7D)),
                onPressed: () => _showInfoDialog('Productivity',
                    'Measures employee output and efficiency based on completed tasks and deadlines.'),
              ),
            ],
          ),
          SizedBox(height: 16),
          Container(
            height: 220,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: 100,
                barTouchData: BarTouchData(
                  enabled: true,
                  touchTooltipData: BarTouchTooltipData(
                    tooltipBgColor: Color(0xFF1A1A1A),
                    getTooltipItem: (group, groupIndex, rod, rodIndex) {
                      return BarTooltipItem(
                        '${employees[groupIndex].name}\n${rod.toY.toInt()}%',
                        TextStyle(color: Colors.white),
                      );
                    },
                  ),
                ),
                titlesData: FlTitlesData(
                  show: true,
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        if (value.toInt() >= 0 && value.toInt() < employees.length) {
                          return Padding(
                            padding: EdgeInsets.only(top: 8),
                            child: Text(
                              employees[value.toInt()].name.split(' ')[0],
                              style: TextStyle(
                                color: Color(0xFF5F6C7D),
                                fontSize: 10,
                              ),
                            ),
                          );
                        }
                        return Text('');
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (double value, TitleMeta meta) {
                        return Text(
                          '${value.toInt()}%',
                          style: TextStyle(
                            color: Color(0xFF5F6C7D),
                            fontSize: 10,
                          ),
                        );
                      },
                    ),
                  ),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                borderData: FlBorderData(show: false),
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 20,
                  getDrawingHorizontalLine: (value) => FlLine(
                    color: Color(0xFFEAECF0),
                    strokeWidth: 1,
                  ),
                ),
                barGroups: employees
                    .asMap()
                    .entries
                    .map((entry) => BarChartGroupData(
                  x: entry.key,
                  barRods: [
                    BarChartRodData(
                      toY: entry.value.productivity.toDouble(),
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF3366FF),
                          Color(0xFF00B8D9),
                        ],
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                      ),
                      width: 16,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ],
                ))
                    .toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAttendanceChart(List<Employee> employees) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 2,
          )
        ],
      ),
      margin: EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Attendance',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1A1A1A),
                ),
              ),
              IconButton(
                icon: Icon(Icons.info_outline, size: 18, color: Color(0xFF5F6C7D)),
                onPressed: () => _showInfoDialog('Attendance',
                    'Shows the percentage of days employees were present and on time.'),
              ),
            ],
          ),
          SizedBox(height: 16),
          Container(
            height: 220,
            child: SfCircularChart(
              series: <CircularSeries>[
                DoughnutSeries<Employee, String>(
                  dataSource: employees,
                  xValueMapper: (Employee data, _) => data.name,
                  yValueMapper: (Employee data, _) => data.attendance,
                  pointColorMapper: (Employee data, _) => _getAttendanceColor(data.attendance),
                  dataLabelMapper: (Employee data, _) => '${data.attendance}%',
                  dataLabelSettings: DataLabelSettings(
                    isVisible: true,
                    labelPosition: ChartDataLabelPosition.outside,
                    textStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                  radius: '80%',
                  innerRadius: '60%',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDepartmentComparisonChart(List<Employee> employees) {
    final departmentStats = <String, Map<String, dynamic>>{};

    for (var employee in employees) {
      if (!departmentStats.containsKey(employee.department)) {
        departmentStats[employee.department] = {
          'count': 0,
          'totalProductivity': 0,
          'totalAttendance': 0,
        };
      }
      departmentStats[employee.department]!['count'] += 1;
      departmentStats[employee.department]!['totalProductivity'] += employee.productivity;
      departmentStats[employee.department]!['totalAttendance'] += employee.attendance;
    }

    final departmentList = departmentStats.keys.toList();

    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 2,
          )
        ],
      ),
      margin: EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Department Comparison',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1A1A1A),
                ),
              ),
              IconButton(
                icon: Icon(Icons.info_outline, size: 18, color: Color(0xFF5F6C7D)),
                onPressed: () => _showInfoDialog('Department Comparison',
                    'Compares average productivity and attendance across departments.'),
              ),
            ],
          ),
          SizedBox(height: 16),
          Container(
            height: 220,
            child: SfCartesianChart(
              primaryXAxis: CategoryAxis(
                labelStyle: TextStyle(color: Color(0xFF5F6C7D)),
              ),
              primaryYAxis: NumericAxis(
                minimum: 0,
                maximum: 100,
                interval: 20,
                labelStyle: TextStyle(color: Color(0xFF5F6C7D)),
              ),
              series: <CartesianSeries>[
                ColumnSeries<DepartmentData, String>(
                  dataSource: departmentList.map((dept) => DepartmentData(
                    dept,
                    (departmentStats[dept]!['totalProductivity'] / departmentStats[dept]!['count']).round(),
                    (departmentStats[dept]!['totalAttendance'] / departmentStats[dept]!['count']).round(),
                  )).toList(),
                  xValueMapper: (DepartmentData data, _) => data.department,
                  yValueMapper: (DepartmentData data, _) => data.productivity,
                  name: 'Productivity',
                  color: Color(0xFF3366FF),
                ),
                ColumnSeries<DepartmentData, String>(
                  dataSource: departmentList.map((dept) => DepartmentData(
                    dept,
                    (departmentStats[dept]!['totalProductivity'] / departmentStats[dept]!['count']).round(),
                    (departmentStats[dept]!['totalAttendance'] / departmentStats[dept]!['count']).round(),
                  )).toList(),
                  xValueMapper: (DepartmentData data, _) => data.department,
                  yValueMapper: (DepartmentData data, _) => data.attendance,
                  name: 'Attendance',
                  color: Color(0xFF00B8D9),
                ),
              ],
              legend: Legend(
                isVisible: true,
                position: LegendPosition.bottom,
                textStyle: TextStyle(fontSize: 12),
              ),
              tooltipBehavior: TooltipBehavior(enable: true),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabIndicator() {
    return Center(
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 8),
        height: 6,
        width: 60,
        decoration: BoxDecoration(
          color: Color(0xFFEAECF0),
          borderRadius: BorderRadius.circular(3),
        ),
        child: Row(
          children: List.generate(3, (index) {
            return Expanded(
              child: AnimatedContainer(
                duration: Duration(milliseconds: 300),
                decoration: BoxDecoration(
                  color: _currentPageIndex == index ? Color(0xFF3366FF) : Colors.transparent,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  Widget _buildPerformanceTable(List<Employee> employees) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            spreadRadius: 2,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Employee Performance',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF1A1A1A),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.download_outlined, size: 20, color: Color(0xFF5F6C7D)),
                  onPressed: () => _exportData(employees),
                  tooltip: 'Export Data',
                ),
              ],
            ),
          ),
          Divider(height: 1, color: Color(0xFFEAECF0)),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columnSpacing: 24,
              columns: [
                DataColumn(
                  label: Text('Employee', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
                DataColumn(
                  label: Text('Department', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
                DataColumn(
                  label: Text('Productivity', style: TextStyle(fontWeight: FontWeight.w600)),
                  numeric: true,
                ),
                DataColumn(
                  label: Text('Attendance', style: TextStyle(fontWeight: FontWeight.w600)),
                  numeric: true,
                ),
                DataColumn(
                  label: Text('Status', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
                DataColumn(
                  label: Text('Actions', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ],
              rows: employees.map((employee) {
                return DataRow(
                  cells: [
                    DataCell(
                      Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            margin: EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              color: employee.isActive ? Color(0xFF00A76F) : Color(0xFF5F6C7D),
                              shape: BoxShape.circle,
                            ),
                          ),
                          CircleAvatar(
                            radius: 16,
                            backgroundImage: NetworkImage(employee.imageUrl),
                          ),
                          SizedBox(width: 8),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                employee.name,
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                              Text(
                                employee.position,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF5F6C7D),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    DataCell(Text(employee.department)),
                    DataCell(
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _getPerformanceColor(employee.productivity).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '${employee.productivity}%',
                          style: TextStyle(
                            color: _getPerformanceColor(employee.productivity),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    DataCell(
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _getAttendanceColor(employee.attendance).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '${employee.attendance}%',
                          style: TextStyle(
                            color: _getAttendanceColor(employee.attendance),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    DataCell(
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: employee.isActive
                              ? Color(0xFF00A76F).withOpacity(0.1)
                              : Color(0xFF5F6C7D).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          employee.isActive ? 'Active' : 'Inactive',
                          style: TextStyle(
                            color: employee.isActive ? Color(0xFF00A76F) : Color(0xFF5F6C7D),
                          ),
                        ),
                      ),
                    ),
                    DataCell(
                      PopupMenuButton(
                        icon: Icon(Icons.more_vert, size: 20, color: Color(0xFF5F6C7D)),
                        itemBuilder: (context) => [
                          PopupMenuItem(
                            child: Row(
                              children: [
                                Icon(Icons.person_outline, size: 18, color: Color(0xFF5F6C7D)),
                                SizedBox(width: 8),
                                Text('View Profile'),
                              ],
                            ),
                            value: 'profile',
                          ),
                          PopupMenuItem(
                            child: Row(
                              children: [
                                Icon(Icons.edit_outlined, size: 18, color: Color(0xFF5F6C7D)),
                                SizedBox(width: 8),
                                Text('Edit'),
                              ],
                            ),
                            value: 'edit',
                          ),
                          PopupMenuItem(
                            child: Row(
                              children: [
                                Icon(Icons.chat_outlined, size: 18, color: Color(0xFF5F6C7D)),
                                SizedBox(width: 8),
                                Text('Send Message'),
                              ],
                            ),
                            value: 'message',
                          ),
                        ],
                        onSelected: (value) => _handleEmployeeAction(value, employee),
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Color _getPerformanceColor(int performance) {
    if (performance >= 90) return Color(0xFF00A76F);
    if (performance >= 75) return Color(0xFF3366FF);
    if (performance >= 50) return Color(0xFFFFAB00);
    return Color(0xFFFF5630);
  }

  Color _getAttendanceColor(int attendance) {
    if (attendance >= 95) return Color(0xFF00A76F);
    if (attendance >= 85) return Color(0xFF3366FF);
    if (attendance >= 70) return Color(0xFFFFAB00);
    return Color(0xFFFF5630);
  }

  void _showInfoDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Got it', style: TextStyle(color: Color(0xFF3366FF))),
          ),
        ],
      ),
    );
  }

  void _handleEmployeeAction(String action, Employee employee) {
    switch (action) {
      case 'profile':
        _showEmployeeProfile(employee);
        break;
      case 'edit':
        _editEmployee(employee);
        break;
      case 'message':
        _sendMessage(employee);
        break;
    }
  }

  void _showEmployeeProfile(Employee employee) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.85,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              Container(
                width: 48,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Employee Profile',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              SizedBox(height: 16),
              CircleAvatar(
                radius: 48,
                backgroundImage: NetworkImage(employee.imageUrl),
              ),
              SizedBox(height: 16),
              Text(
                employee.name,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                employee.position,
                style: TextStyle(
                  color: Color(0xFF5F6C7D),
                ),
              ),
              SizedBox(height: 24),
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xFFF8FAFD),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildProfileStat('Productivity', '${employee.productivity}%',
                        _getPerformanceColor(employee.productivity)),
                    _buildProfileStat('Attendance', '${employee.attendance}%',
                        _getAttendanceColor(employee.attendance)),
                    _buildProfileStat('Status', employee.isActive ? 'Active' : 'Inactive',
                        employee.isActive ? Color(0xFF00A76F) : Color(0xFF5F6C7D)),
                  ],
                ),
              ),
              SizedBox(height: 24),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildProfileDetailItem(Icons.business, 'Department', employee.department),
                      _buildProfileDetailItem(Icons.work, 'Position', employee.position),
                      _buildProfileDetailItem(Icons.event, 'Join Date',
                          DateFormat('MMM d, y').format(employee.joinDate)),
                      _buildProfileDetailItem(Icons.access_time, 'Last Active',
                          DateFormat('MMM d, h:mm a').format(employee.lastActive)),
                      SizedBox(height: 16),
                      Text(
                        'Skills',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: employee.skills
                            .map((skill) => Chip(
                          label: Text(skill),
                          backgroundColor: Color(0xFFEAECF0),
                        ))
                            .toList(),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {},
                child: Text('View Full Profile'),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 48),
                  backgroundColor: Color(0xFF3366FF),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildProfileStat(String label, String value, Color color) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Color(0xFF5F6C7D),
          ),
        ),
      ],
    );
  }

  Widget _buildProfileDetailItem(IconData icon, String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Color(0xFF5F6C7D)),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF5F6C7D),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _editEmployee(Employee employee) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
            height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: EdgeInsets.all(24),
        child: Column(
        children: [
        Container(
        width: 48,
        height: 4,
        decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(2),
        ),
        ),
        SizedBox(height: 16),
        Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
        Text(
        'Edit Employee',
        style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        ),
        ),
        IconButton(
        icon: Icon(Icons.close),
        onPressed: () => Navigator.pop(context),
        ),
        ],
        ),
        SizedBox(height: 16),
        Expanded(
        child: SingleChildScrollView(
        child: Column(
        children: [
        _buildEditField('Name', employee.name),
        _buildEditField('Position', employee.position),
        _buildEditField('Department', employee.department),
        _buildEditField('Productivity', employee.productivity.toString(), isNumber: true),
        _buildEditField('Attendance', employee.attendance.toString(), isNumber: true),
        SwitchListTile(
        title: Text('Active Status'),
        value: employee.isActive,
        onChanged: (value) {},
        activeColor: Color(0xFF3366FF),
        ),
        SizedBox(height: 24),
        Text(
        'Skills',
        style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 16,
        ),
        ),
        SizedBox(height: 8),
        Wrap(
        spacing: 8,
        runSpacing: 8,
        children: employee.skills
            .map((skill) => InputChip(
        label: Text(skill),
        onDeleted: () {},
        deleteIcon: Icon(Icons.close, size: 16),
        ))
            .toList(),
        ),
        SizedBox(height: 8),
        TextButton(
        onPressed: () {},
        child: Text('+ Add Skill'),
        ),
        ],
        ),
        ),
        ),
        SizedBox(height: 16),
        Row(
        children: [
        Expanded(
        child: OutlinedButton(
        onPressed: () => Navigator.pop(context),
        child: Text('Cancel'),
        style: OutlinedButton.styleFrom(
        minimumSize: Size(double.infinity, 48),
        side: BorderSide(color: Color(0xFF3366FF)),
        ),
        ),
        SizedBox(width: 16),
        Expanded(
        child: ElevatedButton(
        onPressed: () {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
        content: Text('Changes saved successfully'),
        behavior: SnackBarBehavior.floating,
        ),
        );
        },
        child: Text('Save Changes'),
        style: ElevatedButton.styleFrom(
        minimumSize: Size(double.infinity, 48),
        backgroundColor: Color(0xFF3366FF)),
        ),
        ),
        ],
        ),
        ],
        ),
        );
        },
    );
  }

  Widget _buildEditField(String label, String value, {bool isNumber = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: TextField(
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        controller: TextEditingController(text: value),
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      ),
    );
  }

  void _sendMessage(Employee employee) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.7,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              Container(
                width: 48,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Message ${employee.name}',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              SizedBox(height: 16),
              Expanded(
                child: TextField(
                  maxLines: null,
                  expands: true,
                  decoration: InputDecoration(
                    hintText: 'Type your message here...',
                    border: InputBorder.none,
                  ),
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Message sent to ${employee.name}'),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                },
                child: Text('Send Message'),
                style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 48),
                    backgroundColor: Color(0xFF3366FF)),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showAddEmployeeDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
            height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: EdgeInsets.all(24),
        child: Column(
        children: [
        Container(
        width: 48,
        height: 4,
        decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(2),
        ),
        ),
        SizedBox(height: 16),
        Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
        Text(
        'Add New Employee',
        style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        ),
        ),
        IconButton(
        icon: Icon(Icons.close),
        onPressed: () => Navigator.pop(context),
        ),
        ],
        ),
        SizedBox(height: 16),
        Expanded(
        child: SingleChildScrollView(
        child: Column(
        children: [
        _buildAddField('Full Name'),
        _buildAddField('Position'),
        _buildAddField('Department'),
        _buildAddField('Productivity (%)', isNumber: true),
        _buildAddField('Attendance (%)', isNumber: true),
        SwitchListTile(
        title: Text('Active Status'),
        value: true,
        onChanged: (value) {},
        activeColor: Color(0xFF3366FF),
        ),
        SizedBox(height: 24),
        Text(
        'Skills',
        style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 16,
        ),
        ),
        SizedBox(height: 8),
        Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [],
        ),
        SizedBox(height: 8),
        TextButton(
        onPressed: () {},
        child: Text('+ Add Skill'),
        ),
        ],
        ),
        ),
        ),
        SizedBox(height: 16),
        Row(
        children: [
        Expanded(
        child: OutlinedButton(
        onPressed: () => Navigator.pop(context),
        child: Text('Cancel'),
        style: OutlinedButton.styleFrom(
        minimumSize: Size(double.infinity, 48),
        side: BorderSide(color: Color(0xFF3366FF)),
        ),
        ),
        SizedBox(width: 16),
        Expanded(
        child: ElevatedButton(
        onPressed: () {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
        content: Text('New employee added successfully'),
        behavior: SnackBarBehavior.floating,
        ),
        );
        },
        child: Text('Add Employee'),
        style: ElevatedButton.styleFrom(
        minimumSize: Size(double.infinity, 48),
        backgroundColor: Color(0xFF3366FF)),
        ),
        ),
        ],
        ),
        ],
        ),
        ),
        },
    );
  }

  Widget _buildAddField(String label, {bool isNumber = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: TextField(
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      ),
    );
  }

  void _exportData(List<Employee> employees) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Exporting data for ${employees.length} employees'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

class Employee {
  final String id;
  final String name;
  final String position;
  final int productivity;
  final int attendance;
  final DateTime lastActive;
  final bool isActive;
  final String department;
  final List<String> skills;
  final DateTime joinDate;
  final String imageUrl;

  Employee({
    required this.id,
    required this.name,
    required this.position,
    required this.productivity,
    required this.attendance,
    required this.lastActive,
    required this.isActive,
    required this.department,
    required this.skills,
    required this.joinDate,
    required this.imageUrl,
  });
}

class DepartmentData {
  final String department;
  final int productivity;
  final int attendance;

  DepartmentData(this.department, this.productivity, this.attendance);
}

class EmployeeSearchDelegate extends SearchDelegate {
  final List<Employee> employees;

  EmployeeSearchDelegate(this.employees);

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    final results = employees.where((e) =>
    e.name.toLowerCase().contains(query.toLowerCase()) ||
        e.position.toLowerCase().contains(query.toLowerCase()) ||
        e.department.toLowerCase().contains(query.toLowerCase()));

    return ListView.builder(
      itemCount: results.length,
      itemBuilder: (context, index) {
        final employee = results.elementAt(index);
        return ListTile(
          leading: CircleAvatar(
            backgroundImage: NetworkImage(employee.imageUrl),
          ),
          title: Text(employee.name),
          subtitle: Text('${employee.position} • ${employee.department}'),
          trailing: Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Color(0xFF00A76F).withOpacity(0.1),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              '${employee.productivity}%',
              style: TextStyle(
                color: Color(0xFF00A76F),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          onTap: () {
            close(context, null);
            _showEmployeeProfile(context, employee);
          },
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    final suggestions = query.isEmpty
        ? employees
        : employees.where((e) =>
    e.name.toLowerCase().contains(query.toLowerCase()) ||
        e.position.toLowerCase().contains(query.toLowerCase()) ||
        e.department.toLowerCase().contains(query.toLowerCase()));

    return ListView.builder(
      itemCount: suggestions.length,
      itemBuilder: (context, index) {
        final employee = suggestions.elementAt(index);
        return ListTile(
          leading: CircleAvatar(
            backgroundImage: NetworkImage(employee.imageUrl),
          ),
          title: Text(employee.name),
          subtitle: Text('${employee.position} • ${employee.department}'),
          trailing: Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Color(0xFF00A76F).withOpacity(0.1),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              '${employee.productivity}%',
              style: TextStyle(
                color: Color(0xFF00A76F),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          onTap: () {
            query = employee.name;
            showResults(context);
          },
        );
      },
    );
  }

  void _showEmployeeProfile(BuildContext context, Employee employee) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
            height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: EdgeInsets.all(24),
        child: Column(
        children: [
        Container(
        width: 48,
        height: 4,
        decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(2),
        ),
        ),
        SizedBox(height: 16),
        Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
        Text(
        'Employee Profile',
        style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        ),
        ),
        IconButton(
        icon: Icon(Icons.close),
        onPressed: () => Navigator.pop(context),
        ),
        ],
        ),
        SizedBox(height: 16),
        CircleAvatar(
        radius: 48,
        backgroundImage: NetworkImage(employee.imageUrl),
        ),
        SizedBox(height: 16),
        Text(
        employee.name,
        style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        ),
        ),
        Text(
        employee.position,
        style: TextStyle(
        color: Color(0xFF5F6C7D),
        ),
        ),
        SizedBox(height: 24),
        Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
        color: Color(0xFFF8FAFD),
        borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
        _buildProfileStat('Productivity', '${employee.productivity}%',
        Color(0xFF00A76F)),
        _buildProfileStat('Attendance', '${employee.attendance}%',
        Color(0xFF3366FF)),
        _buildProfileStat('Status', employee.isActive ? 'Active' : 'Inactive',
        employee.isActive ? Color(0xFF00A76F) : Color(0xFF5F6C7D)),
        ],
        ),
        ),
        SizedBox(height: 24),
        Expanded(
        child: SingleChildScrollView(
        child: Column(
        children: [
        _buildProfileDetailItem(Icons.business, 'Department', employee.department),
        _buildProfileDetailItem(Icons.work, 'Position', employee.position),
        _buildProfileDetailItem(Icons.event, 'Join Date',
        DateFormat('MMM d, y').format(employee.joinDate)),
        _buildProfileDetailItem(Icons.access_time, 'Last Active',
        DateFormat('MMM d, h:mm a').format(employee.lastActive)),
        SizedBox(height: 16),
        Text(
        'Skills',
        style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 16,
        ),
        ),
        SizedBox(height: 8),
        Wrap(
        spacing: 8,
        runSpacing: 8,
        children: employee.skills
            .map((skill) => Chip(
        label: Text(skill),
        backgroundColor: Color(0xFFEAECF0),
        ))
            .toList(),
        ),
        ],
        ),
        ),
        ),
        SizedBox(height: 16),
        ElevatedButton(
        onPressed: () {},
        child: Text('View Full Profile'),
        style: ElevatedButton.styleFrom(
        minimumSize: Size(double.infinity, 48),
        backgroundColor: Color(0xFF3366FF)),
        ),
        ],
        ),
        );
      },
    );
  }

  Widget _buildProfileStat(String label, String value, Color color) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Color(0xFF5F6C7D),
          ),
        ),
      ],
    );
  }

  Widget _buildProfileDetailItem(IconData icon, String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Color(0xFF5F6C7D)),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF5F6C7D),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}